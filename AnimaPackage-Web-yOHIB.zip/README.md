# TILWebsite
This code was generated using AnimaApp.com. 
Anima allows teams to innovate faster by converting design to code, automatically.

## Are you a developer?
This code is a high-fidelity prototype.
Get developer-friendly React or HTML/CSS code for this project at:
https://projects.animaapp.com/team/website-design-ujgdwow/project/puoQWLZ?utm_source=package-code
You might need to request access.

## Got feedback?
Feedback on code quality is welcome at code@animaapp.com.

Have a creative day,
Anima team
